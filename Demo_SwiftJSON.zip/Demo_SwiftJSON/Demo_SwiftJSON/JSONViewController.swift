//  ViewController.swift
//  Demo_SwiftJSON
//
//  Created by   on 09/12/16.
//  Copyright © 2016  . All rights reserved.

import UIKit
import Foundation
import Alamofire

class JSONViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        jsongetmethod()
        jsonpostmethod()
        
        stringToDict()
    }

    // MARK: Json Parsing using POST Method
    func jsonpostmethod()
    {
        //declare parameter as a dictionary which contains string as key and value combination.
        // MARK: Pass Dictionary to JSON
        let parameters = ["Unique_Id":"938C45E0-B97F-4C12-99DE-0B36B0B14824"] as Dictionary<String, String>
        
         // MARK: create the url with NSURL
        let url = NSURL(string: "https://appreviewbooster.com/PlayEarnAPI/Service.svc/RegisterUser")
        
         // MARK: now create the NSMutableRequest object using the url object
        let request = NSMutableURLRequest(url: url! as URL)
        request.httpMethod = "POST" //set http method as POST
        
        do
        {
            // MARK: pass dictionary to nsdata object and set it as request body
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        }
        catch let error
        {
            print(error.localizedDescription)
        }
        
        // MARK: HTTP Headers Value
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        //request.addValue("vikash", forHTTPHeaderField: "007vikash")
        
        // MARK: make seesion task
        URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) in
            
            if error != nil
            {
                print("error = \(String(describing: error))")
                return
            }
            do {
                // MARK: Convert JsonData to NSString
                let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("responseString = \(String(describing: responseString))")
                
                // MARK: Convert JsonData to NSDictionary
                let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                print ("json Dict \n = \(json) ")
                
                if (json["Message"] as! NSString) .isEqual(to: "Successful") && (json["Status"] as! NSString) .isEqual(to: "true") {
                    
                    let yourItems : NSMutableArray = [json]
                    print ("json Dict \n = \(yourItems) ")
                    
                    let arrobj: CustomeMethod = CustomeMethod() //Create object of CustomeMethod
                    arrobj.CommonDetail = [json["CommonDetail"] as Any] 
                    arrobj.UserDetail = [json["UserDetail"] as Any]
                    
                    print ("arrobj.CommonDetail \n = \(arrobj.CommonDetail) ")
                    print ("arrobj.UserDetail \n = \(arrobj.UserDetail) ")
                    
                    // MARK: Get String object from NSDictionary
                    let str = json["Message"] as! NSString
                    print ("ResultMsg = \(str)")
                    
                    // MARK: JSON Response
                    
                    // MARK: Get 2nd array data from NSDictionary
                    let allBars = json["CommonDetail"] as! NSDictionary
                    
                    let Reg_key = allBars["AdAppNext_Id"] as! NSString
                    let Reg_key1 = allBars["AdColonyAppId"] as! NSString
                    let Reg_key2 = allBars["AdColonyZoneId"] as! NSString
                    
                    print ("Reg_key = \(Reg_key,Reg_key1,Reg_key2)")
                    
                    // MARK: Set & Get Value from NSuserdefault
                    let defaults = UserDefaults.standard
                    defaults.set(Reg_key1, forKey: "Reg_key1")
                    defaults.set(123, forKey: "num")
                    print(defaults.integer(forKey: "num"))
                    
                    if let name = defaults.string(forKey: "Reg_key1")
                    {
                        print(name)
                    }
                    
                    // MARK: Convert NSDictionary to NSData
                    let dataExample: Data = NSKeyedArchiver.archivedData(withRootObject: allBars)
                    
                    // MARK: Convert NSData to NSDictionary
                    let dictionary: NSDictionary? = NSKeyedUnarchiver.unarchiveObject(with: dataExample) as? [String : Any] as NSDictionary?
                    print(dataExample)
                    print(dictionary as Any)
                }
                
                //NSRange range = [requestReply rangeOfString:"status"];
            }
            catch let error as NSError
            {
                print("Error : " + error.localizedDescription)
            }
        }).resume()
    }

    // MARK: Json Parsing using GET Method
    func jsongetmethod()
    {
        let requestURL: NSURL = NSURL(string: "http://www.learnswiftonline.com/Samples/subway.json")!
        let urlRequest: NSMutableURLRequest = NSMutableURLRequest(url: requestURL as URL)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest as URLRequest)
        {
            (data, response, error) -> Void in
            
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if (statusCode == 200)
            {
                print("Json Data: \(String(describing: data))")
                
                if let jsonString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                {
                    print("JSON: \n\n \(jsonString)")
                }
            }
        }
        task.resume()
    }
    
    // MARK: String To Dictionary
    func stringToDict() {
        
        // MARK: Dictionary Method - 1
        let dictionary1 = CustomeMethod.convertToDictionary(from: "{\"City\":\"Paris\"}")
        print(dictionary1)
        
        // MARK: Dictionary Method - 2
        let parameters = ["app_id":"226", "packagename":"testmode"] as Dictionary<String, String>
        print(parameters)
        
        // MARK: Dictionary Method - 3 (Open Below link And You can see multiple method)
        
        //http://stackoverflow.com/questions/30480672/how-to-convert-a-json-string-to-a-dictionary
    }
    
    //MARK:- Validetion
//    private func validate() -> Bool {
//        if IS_INTERNET_AVAILABLE() == false {
//            let alert = UIAlertController(title: CONNECTION_TITLE, message: CONNECTION_MSG, preferredStyle: UIAlertControllerStyle.alert)
//            alert.addAction(UIAlertAction(title: "OK", style:UIAlertActionStyle.default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//            return false
//        }
//        var msg : String! = nil
//        if (txtEmailID.text?.trim().isEmpty == true) {
//            msg = "Please \(txtEmailID.placeholder!)"
//        }
//        else if (txtPass.text?.trim().isEmpty == true){
//            msg = "Please \(txtPass.placeholder!)"
//        }
//
//        if msg != nil {
//
//            appDelegate.window!.rootViewController!.view.makeToast("\(msg!)")
//
//            return false
//        }
//
//        return true
//    }
    
    //MARK:- Button Action
//    @IBAction func BtnActionLogin(_ sender: Any)
//    {
//        if self.validate() == false{
//            return
//
//        }
//
//
//        SetLoginData()
//    }
    
    //MARK:- Custome method or webservice
//    func SetLoginData()
//    {
//        let param = NSDictionary(dictionary: ["first_key":FIST_KEY,"email":txtEmailID.text!,"device_id":DEIVACE_ID,"device_type":DEVICE_TYPE,"password":txtPass.text!,"token":"kjhkjhghh"])
//
//        MBProgressHUD.showAdded(to: self.view, animated: true)
//
//        WebService.postURL(MAIN_LINK, methodname: LOGIN, param: param) { (success, response) in
//
//            MBProgressHUD.hide(for: self.view, animated: true)
//
//            if success == true
//            {
//                print(response)
//
//                UserDefaults.standard.set(response, forKey: "LoginData")
//                UserDefaults.standard.synchronize()
//
//                if let user_id = response.object(forKey: "user_id")
//                {
//                    UserDefaults.standard.set("\(user_id)", forKey: "user_id")
//                    UserDefaults.standard.synchronize()
//                }
//
//                if let key = response.object(forKey: "key")
//                {
//                    UserDefaults.standard.set("\(key)", forKey: "app_key")
//                    UserDefaults.standard.synchronize()
//                }
//
//                self.appD.SetRootView(isLogging: true)
//            }
//            else
//            {
//                print("fail")
//
//                if let msg = response.object(forKey: "message") as? String
//                {
//                    self.view.makeToast("\(NSLocalizedString(msg, comment: ""))")
//                }
//                else
//                {
//                    let alert = UIAlertController(title: "\(NSLocalizedString("Alert", comment: ""))", message: "\(NSLocalizedString("Server is low so please try after some time or try again", comment: ""))", preferredStyle: .alert)
//
//                    let tryagain = UIAlertAction(title: "\(NSLocalizedString("Try Again", comment: ""))", style: .default, handler: { (act) in
//                        self.SetLoginData()
//                    })
//
//                    let canecl = UIAlertAction(title: "\(NSLocalizedString("Cancel", comment: ""))", style: .cancel, handler: { (act) in
//                        //                        self.navigationController?.popToRootViewController(animated: true)
//                    })
//
//                    alert.addAction(tryagain)
//                    alert.addAction(canecl)
//
//                    self.present(alert, animated: true, completion: nil)
//                }
//
//            }
//        }
//    }
    
    
//    //MARK:- Custome Method For array to table view
//
//    func GetFAQ()
//    {
//
//
//        let param = NSDictionary(dictionary: ["first_key":FIRST_KEY])
//
//        MBProgressHUD.showAdded(to: self.view, animated: true)
//
//        WebService.postURL(MAIN_LINK, methodname: GET_FAQ, param: param, CompletionHandler: { (success, response) in
//
//            MBProgressHUD.hide(for: self.view, animated: true)
//
//            if success == true
//            {
//                if let faq_questions = response.object(forKey: "faq_questions") as? NSArray
//                {
//                    self.questionarray = NSMutableArray(array: faq_questions)
//                }
//                self.tblFaqs.reloadData()
//            }
//            else
//            {
//                print("fail")
//                if let msg = response.object(forKey: "message") as? String
//                {
//                    self.view.makeToast("\(NSLocalizedString(msg, comment: ""))")
//                }
//                else
//                {
//                    let alert = UIAlertController(title: "\(NSLocalizedString("Alert", comment: ""))", message: "\(NSLocalizedString("Server is low so please try after some time or try again", comment: ""))", preferredStyle: .alert)
//
//                    let tryagain = UIAlertAction(title: "\(NSLocalizedString("Try Again", comment: ""))", style: .default, handler: { (act) in
//                        self.GetFAQ()
//                    })
//
//                    let canecl = UIAlertAction(title: "\(NSLocalizedString("Cancel", comment: ""))", style: .cancel, handler: { (act) in
//                        self.navigationController?.popToRootViewController(animated: true)
//                    })
//
//                    alert.addAction(tryagain)
//                    alert.addAction(canecl)
//
//                    self.present(alert, animated: true, completion: nil)
//                }
//            }
//        })
//
//
//
//    }
//
//}
//
//extension FAQsVC : UITableViewDelegate,UITableViewDataSource
//{
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return questionarray.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
//
//        cell?.selectionStyle = .none
//
//        let lblNumber = cell?.viewWithTag(10) as! UILabel
//        let lblQuestion = cell?.viewWithTag(20) as! UILabel
//
//        let lblAn = cell?.viewWithTag(30) as! UILabel
//        let lblAns = cell?.viewWithTag(40) as! UILabel
//
//        let MAINView = cell?.contentView.viewWithTag(100)! as! UIView
//        lblNumber.text = "\(indexPath.row + 1)"
//
//        MAINView.layer.masksToBounds = false
//        MAINView.layer.shadowOffset = CGSize(width: 1, height: 3)
//        MAINView.layer.shadowRadius = 2
//        MAINView.layer.shadowOpacity = 0.5
//        MAINView.layer.shadowColor = UIColor.lightGray.cgColor
//
//        if let dict = questionarray.object(at: indexPath.row) as? NSDictionary
//        {
//            if let faq_question_number = dict.object(forKey: "faq_question_number")
//            {
//                lblNumber.text = "\(faq_question_number)."
//            }
//
//            if let faq_question = dict.object(forKey: "faq_question") as? String
//            {
//                lblQuestion.text = faq_question
//            }
//
//            if Selected_row != nil
//            {
//                if Selected_row == indexPath.row
//                {
//                    lblAn.text = "Ans: "
//
//                    if let faq_answer = dict.object(forKey: "faq_answer") as? String
//                    {
//                        lblAns.text = faq_answer
//                    }
//
//                    MAINView.backgroundColor = Constant.UIColorFromHex(0xECF0F9)
//                }
//                else
//                {
//                    lblAn.text = ""
//                    lblAns.text = ""
//
//                    MAINView.backgroundColor = UIColor.white
//                }
//
//
//            }
//            else
//            {
//                lblAn.text = ""
//                lblAns.text = ""
//                MAINView.backgroundColor = UIColor.white
//            }
//        }
//
//
//
//        return cell!
//
//    }
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        Selected_row = indexPath.row
//
//        tblFaqs.reloadData()
//    }
//}
    
    //MARK:- passtring data into request
//    var request = URLRequest(url: URL(string: "URL")!)
//    request.httpMethod = "POST"
//
//    let postString = "tag=register&name="+userName+"&email="+fullEmail.text!+"&password="+userPassword+"&age="+userAge+"&gender="+userGender+"&country="+con+"&county="+fullLocation.text!
//
//    request.httpBody = postString.data(using: .utf8)
//    let task = URLSession.shared.dataTask(with: request) { data, response, error in
//        guard let data = data, error == nil else
//        {                                                 // check for fundamental networking error
//            //print("error=\()")
//            return
//        }
//
//        if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
//            //print("statusCode should be 200, but is \(httpStatus.statusCode)")
//            print("response = \(String(describing: response))")
//        }
//
//        let responseString = String(data: data, encoding: .utf8)
//        print("responseString = \(String(describing: responseString))")
//    }
//    task.resume()
//    performSegue(withIdentifier: "surveyScreen", sender: nil)
    
    //MARK:- Use import SwiftyJSON
//    Alamofire.request(baseurl, method: .post, parameters: parameters, encoding: URLEncoding.default).responseJSON { (responseData) -> Void in
//
//    self.view.isUserInteractionEnabled = false
//    self.indicator.stopAnimating()
//    if((responseData.result.value) != nil) {
//    let swiftyJsonVar = JSON(responseData.result.value!)
//
//    print(swiftyJsonVar)
//
//    if swiftyJsonVar["success"] == 1 {
//
//    self.performSegue(withIdentifier: "tabScreen", sender: nil)
//    }
//    else
//    {
//    let myAlert = UIAlertController(title: "Alert", message: "Something went wrong, please try Again", preferredStyle: UIAlertControllerStyle.alert)
//
//    let okButton = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
//
//    myAlert.addAction(okButton)
//    self.present(myAlert, animated: true, completion: nil)
//    UserDefaults.standard.set(nil, forKey: "userName")
//    }
//    }
//    }
}
