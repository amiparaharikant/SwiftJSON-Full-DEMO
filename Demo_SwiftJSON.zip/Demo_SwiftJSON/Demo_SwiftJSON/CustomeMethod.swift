//  CustomeMethod.swift
//  Demo_SwiftJSON
//
//  Created by   on 06/04/17.
//  Copyright © 2017  . All rights reserved.

import UIKit
import GoogleMobileAds
import Foundation

var dateClickStr: AnyObject?

class CustomeMethod: NSObject,GADInterstitialDelegate,GADBannerViewDelegate,UIAlertViewDelegate
{
    var Arrayresults: NSMutableArray = []
    
    var CommonDetail: NSMutableArray = []
    var UserDetail: NSMutableArray = []
    
    
    class func addGADBannerView_ViewController(_ vc: UIViewController) -> GADBannerView
    {
        dateClickStr = UserDefaults.standard.object(forKey: mDateforClickAD) as? Date as AnyObject?
        
//        if UserDefaults.standard.bool(forKey: mRemoveAd) {
//            return
//        }
//        
        
//        if (NSCalendar.current.isDateInToday(dateClickStr! as! Date)){
//            return
//        }
//        
        if(UIDevice.current.userInterfaceIdiom == .phone ){
            kIadBannerHeight = 50
            print("iphone \(kIadBannerHeight)")
        } else {
            kIadBannerHeight = 90
            print("ipad \(kIadBannerHeight)")
        }
        
        var GadBannerView = GADBannerView()
        if !UserDefaults.standard.bool(forKey: mRemoveAd)
        {
            GadBannerView = GADBannerView(frame: CGRect(x: CGFloat(0), y: CGFloat(kScreenHeight - 50), width: CGFloat(kScreenWidth), height: CGFloat(kIadBannerHeight)))
            GadBannerView.adUnitID = kAdUnitID
            GadBannerView.rootViewController = vc
            GadBannerView.adSize=kGADAdSizeSmartBannerPortrait
            let request:GADRequest = GADRequest()
            request.testDevices = [kGADSimulatorID]
            GadBannerView.load(request);
        }
        return GadBannerView
    }
    
    class func isAdisReadyToviewBanner() -> Bool
    {
        if UserDefaults.standard.bool(forKey: mRemoveAd) {
            return false
        }
        
        print("yourDate: \(String(describing: dateClickStr))")
        if (NSCalendar.current.isDateInToday(dateClickStr! as! Date)){
            return false
        }
        
        return true
    }
    
    class func isAdisReadyToviewIntrestial() -> Bool
    {
        if UserDefaults.standard.bool(forKey: mRemoveAd) {
            return false
        }
        
        print("yourDate: \(String(describing: dateClickStr))")
        if (NSCalendar.current.isDateInToday(dateClickStr! as! Date)){
            return false
        }
        
        return true
    }
    
    class func showingInterstitialAdonController(_ controller: UIViewController) {
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: klastIntAdShowTime)
        UserDefaults.standard.synchronize()
    }
    
    class func addGADInterstitial_ViewController(_ vc: UIViewController) -> GADInterstitial{
        
        dateClickStr = UserDefaults.standard.object(forKey: mDateforClickAD) as? Date as AnyObject?
        
//        if UserDefaults.standard.bool(forKey: mRemoveAd) {
//            return
//        }
//        
//        if (NSCalendar.current.isDateInToday(dateClickStr! as! Date)){
//            return
//        }
        
        let interstitial = GADInterstitial(adUnitID: kAdIntrestialID)
        if !UserDefaults.standard.bool(forKey: mRemoveAd)
        {
            //interstitial.delegate = vc
            let request:GADRequest = GADRequest()
            request.testDevices = []
            interstitial.load(request)
        }
        return interstitial
    }
    
    class func dismissInterstitialAdonController(_ controller: UIViewController){
        
        print("mData \(String(describing: UserDefaults.standard.object(forKey: mDateforClickAD)))")
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(0.5 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: {() -> Void in
            
            if (NSCalendar.current.isDateInToday(dateClickStr! as! Date))
            {
                showCustomeAlertOkCancel(withTitle:"##AdBlock Activated##!", withMessage:"AdBlock is Active for today", withButtonTitleLeft: "Cancel", withButtonTitleRight: "Done")
            }
            else
            {
                showCustomeAlertOkCancel(withTitle:"##Best Hint##", withMessage:"if you visit an appropriate ad for you then #AdBlock# will not let you disturb for same day again", withButtonTitleLeft: "Done")
                
                let alertView = UIAlertController(title: "##Best Hint##", message: "if you visit an appropriate ad for you then #AdBlock# will not let you disturb for same day again", preferredStyle: .alert)
                
                alertView.addAction(UIAlertAction(title: "OK",
                                                  style: .default,
                                                  handler: nil))
                
                alertView.addAction(UIAlertAction(title: "Buy", style: .default, handler: { (action : UIAlertAction!) -> Void in
                    
                }))
                
                UIApplication.shared.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
            }
        })
    }
    
    class func clickOnAdHappenonController (_ controller: UIViewController) {
        UserDefaults.standard.set(Date(), forKey: mDateforClickAD)
        UserDefaults.standard.synchronize()
    }    
    
    //MARK: How to Use ->  ALERT showCustomeAlertOkCancle
    //showCustomeAlertOkCancel(withTitle:"##AdBlock Activated##!", withMessage:"AdBlock is Active for today", withButtonTitleLeft: "Cancel", withButtonTitleRight: "Done")
    class func showCustomeAlertOkCancel(withTitle: String = "", withMessage: String,  withButtonTitleLeft: String = "", withButtonTitleRight: String = ""){
        
        let alertView = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
        
        alertView.addAction(UIAlertAction(title: withButtonTitleLeft, style: .default, handler: { (action : UIAlertAction!) -> Void in
            
            // call delegate method to perform confirmed action, - i.e. remove
        }))
        
        if !withButtonTitleRight.isEmpty {
            // Confirm action
            alertView.addAction(UIAlertAction(title: withButtonTitleRight,
                                              style: .cancel,
                                              handler: { (action : UIAlertAction!) -> Void in
                                                // call delegate method to perform confirmed action, - i.e. remove
            }))
        }
    
        UIApplication.shared.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
    
    //MARK: ALERT showCustomeAlertOpenUrl
    //showCustomeAlertOpenUrl(withTitle:"##AdBlock Activated##!", withMessage:"AdBlock is Active for today", withButtonTitleLeft: "Cancel", withButtonTitleUrl: "Done", withOpenUrlString: "google")
    class func showCustomeAlertOpenUrl(withTitle: String = "", withMessage: String,  withButtonTitleLeft: String = "", withButtonTitleUrl: String = "", withOpenUrlString: String = ""){
        
        let alertView = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
        
        if !withButtonTitleLeft.isEmpty {
            // Confirm action
            alertView.addAction(UIAlertAction(title: withButtonTitleLeft,
                                              style: .cancel,
                                              handler: nil))
        }
        
        alertView.addAction(UIAlertAction(title: withButtonTitleUrl, style: .default, handler: { (action : UIAlertAction!) -> Void in
            
            UIApplication.shared.openURL(NSURL(string: withOpenUrlString)! as URL)
        }))
        
        UIApplication.shared.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
    
    //MARK: How to Use -> ALERT showAlertTitleOnly
    //showAlertTitleOnlyFromView(withTitle:"##Best Hint##", withMessage:"will not let you disturb for same day again", withButtonTitleLeft: "Done")
    class func showAlertTitleOnlyFromView(_ title: String, withMessage message: String, withButttonTitle Title: String, onView viewController: UIViewController){
        
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertView.addAction(UIAlertAction(title: message,
                                          style: .default,
                                          handler: { (action : UIAlertAction!) -> Void in
                                            // call delegate method to perform confirmed action, - i.e. remove
                                            print("alert cancel method call")
        }))
        
        viewController.present(alertView, animated: true, completion: nil)
    }
    
    class func showCustomeAlertTextfield(withTitle: String = "", withMessage: String,  withButtonTitleLeft: String = "", withButtonTitleRight: String = "", withTextfieldTextHolderText: String = "")
    {
        var loginTextField: UITextField?
        let alertView = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
        
        alertView.addAction(UIAlertAction(title: withButtonTitleRight, style: .default, handler: { (action : UIAlertAction!) -> Void in
            
            if (loginTextField?.text == "123"){
                print("TextField value \(String(describing: loginTextField?.text))")
            }
            else
            {
                
            }
        }))
        
        if !withButtonTitleLeft.isEmpty {
            // Confirm action
            alertView.addAction(UIAlertAction(title: withButtonTitleLeft,
                                              style: .cancel,
                                              handler: nil))
        }
        
        alertView.addTextField { (textField) -> Void in
            // Enter the textfiled customization code here.
            loginTextField = textField
            loginTextField?.placeholder = withTextfieldTextHolderText
        }
        
        UIApplication.shared.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
    
    class func convertToDictionary(from text: String) -> [String: String] {
        guard let data = text.data(using: .utf8) else { return [:] }
        let anyResult: Any? = try? JSONSerialization.jsonObject(with: data, options: [])
        return anyResult as? [String: String] ?? [:]
    }
    
    //MARK: Date Functionality
    class func isLaterThanOrEqual(to date: Date) -> Bool{
        return !(date.compare(date) == .orderedAscending)
    }

    class func isEarlierThanOrEqual(to date: Date) -> Bool{
        return !(date.compare(date) == .orderedDescending)
    }
    
    class func isLaterThan(_ date: Date) -> Bool{
        return (date.compare(date) == .orderedDescending)
    }
    
    class func isEarlierThan(_ date: Date) -> Bool{
        return (date.compare(date) == .orderedAscending)
    }
    
    class func isSameDay(_ date: Date) -> Bool{
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day])
        var comp1: DateComponents? = calendar.dateComponents(unitFlags, from: date)
        var comp2: DateComponents? = calendar.dateComponents(unitFlags, from: date)
        print("comp1 \(String(describing: comp1)) comp2 \(String(describing: comp2))")
        
        if comp1?.year == comp2?.year && comp1?.month == comp2?.month && comp1?.day == comp2?.day{
            print("same date")
        }else{
            print("different date")
        }
        
        return comp1?.day! == comp2?.day! && comp1?.month! == comp2?.month! && comp1?.year! == comp2?.year!
    }
    
    class func hudShowWith(_ title: String, withMessage message: String, onView viewController: UIView){
        
        MBProgressHUD.hide(for: viewController, animated: true)
        let HUD = MBProgressHUD.showAdded(to: viewController, animated: true);
        
        HUD?.labelText = title
        HUD?.detailsLabelText = message
        HUD?.isUserInteractionEnabled = true
    }
    
    class func hudShowDefault(_ viewController: UIView){
        
        MBProgressHUD.hide(for: viewController, animated: true)
        let HUD = MBProgressHUD.showAdded(to: viewController, animated: true);
        
        HUD?.labelText = "Loading"
        HUD?.detailsLabelText = "Please Wait!!"
        HUD?.isUserInteractionEnabled = true
    }
    
    class func hudHide(_ title: String, withMessage message: String, onView viewController: UIView){
        
        MBProgressHUD.hide(for: viewController, animated: true)
    }
}
