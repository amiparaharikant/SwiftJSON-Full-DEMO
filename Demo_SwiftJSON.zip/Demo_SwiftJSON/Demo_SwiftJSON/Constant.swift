
import Foundation
import SystemConfiguration
import CoreLocation
import UserNotifications

let APP_Name: String = "AppName"
let kAdIntrestialID = "ca-app-pub-9302166674875198/7759344260"
let mShowAdAfter = 40.0
let klastIntAdShowTime = "lastIntAdShowTime"
let mRemoveAd = "com.apple.zipextractorappfree.RemoveAd"
let hintProduct = "com.apple.christmasnightfallfacehiddenobjects.hint"
let mDateforClickAD = "DateforClickAD"
let kAdUnitID = "ca-app-pub-9302166674875198/6282611063"
let kScreenHeight: CGFloat = UIScreen.main.bounds.size.height
//var kIadBannerHeight: CGFloat = (((UIScreen.main.bounds.size.width) - 320) ? 66 : 50)
let kScreenWidth = UIScreen.main.bounds.size.width

let mINTERSTETIALADTIMEAFTER = 3.0
var kIadBannerHeight = 0

 //MARK : RemoveAdProducts
public struct RemoveAdProducts {
  
  public static let mRemoveAdIdentifier = mRemoveAd
  
  fileprivate static let productIdentifiers: Set<ProductIdentifier> = [RemoveAdProducts.mRemoveAdIdentifier]

  public static let store = IAPHelper(productIds: RemoveAdProducts.productIdentifiers)
}

 //MARK : HintProducts
public struct HintProducts {
    
    public static let HintProductsIdentifier = hintProduct
    
    fileprivate static let productIdentifiers: Set<ProductIdentifier> = [HintProducts.HintProductsIdentifier]
    
    public static let store = IAPHelper(productIds: HintProducts.productIdentifiers)
}

func resourceNameForProductIdentifier(_ productIdentifier: String) -> String? {
  return productIdentifier.components(separatedBy: ".").last
}

class Constant: NSObject {
    
    class func UIColorFromHex(_ rgbValue: UInt) -> UIColor
    {
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1)
        )
    }
    
    class func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

// statusBar View
extension UIApplication {
    var statusBarView: UIView? {
        return value(forKey: "statusBar") as? UIView
    }
}

let appDelegate = UIApplication.shared.delegate as! AppDelegate
//MARK: - Directory Constants.....
private let pathsForDocDir = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)

let DOCUMENT_DIRECTORY: AnyObject = pathsForDocDir[0] as AnyObject

private let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.libraryDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)

let LIBRARY_DIRECTORY: AnyObject = paths[0] as AnyObject

let DIR_USERDATA = (LIBRARY_DIRECTORY as! String).appending(".UserData")

//MARK :- CornerRedias
extension UIView{
    func CircleRoundsView() {
        self.layer.cornerRadius = self.bounds.size.width / 50
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor(red:255/255.0, green:82/255.0, blue:50/255.0, alpha: 1.0).cgColor
        self.clipsToBounds = true
    }
}

extension UIButton{
    func CircleRoundsuisButton() {
        self.layer.cornerRadius = self.bounds.size.height / 2
        self.clipsToBounds = true
    }
}

extension UITextField{
    func CircleRoundsuistextField() {
        self.layer.cornerRadius = self.bounds.size.height / 2
        self.layer.borderWidth = 2.0
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.clipsToBounds = true
    }
}

extension UIView{
    func BackgroundColorGradientLayer(){
        let colorTop =  UIColor(red: 255.0/255.0, green: 149.0/255.0, blue: 0.0/255.0, alpha: 1.0).cgColor
        let colorBottom = UIColor(red: 255.0/255.0, green: 94.0/255.0, blue: 58.0/255.0, alpha: 1.0).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.locations = [ 0.0, 1.0]
    }
}

extension UIImage {
    
    func resized(withPercentage percentage: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: size.width * percentage, height: size.height * percentage)
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
    
    func resized(toWidth width: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}

//MARK :- GradientView
@IBDesignable
class GradientView: UIView {
    
    @IBInspectable var startColor:   UIColor = .black { didSet { updateColors() }}
    @IBInspectable var endColor:     UIColor = .white { didSet { updateColors() }}
    @IBInspectable var startLocation: Double =   0.05 { didSet { updateLocations() }}
    @IBInspectable var endLocation:   Double =   0.95 { didSet { updateLocations() }}
    @IBInspectable var horizontalMode:  Bool =  false { didSet { updatePoints() }}
    @IBInspectable var diagonalMode:    Bool =  false { didSet { updatePoints() }}
    
    override class var layerClass: AnyClass { return CAGradientLayer.self }
    
    var gradientLayer: CAGradientLayer { return layer as! CAGradientLayer }
    
    func updatePoints() {
        if horizontalMode {
            gradientLayer.startPoint = diagonalMode ? CGPoint(x: 1, y: 0) : CGPoint(x: 0, y: 0.5)
            gradientLayer.endPoint   = diagonalMode ? CGPoint(x: 0, y: 1) : CGPoint(x: 1, y: 0.5)
        } else {
            gradientLayer.startPoint = diagonalMode ? CGPoint(x: 0, y: 0) : CGPoint(x: 0.5, y: 0)
            gradientLayer.endPoint   = diagonalMode ? CGPoint(x: 1, y: 1) : CGPoint(x: 0.5, y: 1)
        }
    }
    func updateLocations() {
        gradientLayer.locations = [startLocation as NSNumber, endLocation as NSNumber]
    }
    func updateColors() {
        gradientLayer.colors    = [startColor.cgColor, endColor.cgColor]
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updatePoints()
        updateLocations()
        updateColors()
    }
}
@IBDesignable
class GradientButton: UIButton {
    
    @IBInspectable var startColor:   UIColor = .black { didSet { updateColors() }}
    @IBInspectable var endColor:     UIColor = .white { didSet { updateColors() }}
    @IBInspectable var startLocation: Double =   0.05 { didSet { updateLocations() }}
    @IBInspectable var endLocation:   Double =   0.95 { didSet { updateLocations() }}
    @IBInspectable var horizontalMode:  Bool =  false { didSet { updatePoints() }}
    @IBInspectable var diagonalMode:    Bool =  false { didSet { updatePoints() }}
    
    override class var layerClass: AnyClass { return CAGradientLayer.self }
    
    var gradientLayer: CAGradientLayer { return layer as! CAGradientLayer }
    
    func updatePoints() {
        if horizontalMode {
            gradientLayer.startPoint = diagonalMode ? CGPoint(x: 1, y: 0) : CGPoint(x: 0, y: 0.5)
            gradientLayer.endPoint   = diagonalMode ? CGPoint(x: 0, y: 1) : CGPoint(x: 1, y: 0.5)
        } else {
            gradientLayer.startPoint = diagonalMode ? CGPoint(x: 0, y: 0) : CGPoint(x: 1.5, y: 0)
            gradientLayer.endPoint   = diagonalMode ? CGPoint(x: 1, y: 1) : CGPoint(x: 1.5, y: 1)
        }
    }
    func updateLocations() {
        gradientLayer.locations = [startLocation as NSNumber, endLocation as NSNumber]
    }
    func updateColors() {
        gradientLayer.colors    = [startColor.cgColor, endColor.cgColor]
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updatePoints()
        updateLocations()
        updateColors()
    }
}


//MARK: - Other Constants.....
let CONNECTION_TITLE = "Connection Error!"
let CONNECTION_MSG = "The Internet connection appears to be offline."

extension String {
    func trim() -> String {
        
        return self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
    }
}
extension UIImage {
    
    func resizeImage(image: UIImage, newSize: CGSize) -> (UIImage) {
        
        let newRect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height).integral
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0)
        let context = UIGraphicsGetCurrentContext()
        
        // Set the quality level to use when rescaling
        context!.interpolationQuality = CGInterpolationQuality.default
        let flipVertical = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: 0, ty: newSize.height)
        
        context!.concatenate(flipVertical)
        // Draw into the context; this scales the image
        context?.draw(image.cgImage!, in: CGRect(x: 0.0,y: 0.0, width: newRect.width, height: newRect.height))
        
        let newImageRef = context!.makeImage()! as CGImage
        let newImage = UIImage(cgImage: newImageRef)
        
        // Get the resized image from the context and a UIImage
        UIGraphicsEndImageContext()
        
        return newImage
    }
}

func IS_INTERNET_AVAILABLE()->Bool{
    
    var Status:Bool = false
    let url = URL(string: "http://google.com/")
    let request = NSMutableURLRequest(url: url!)
    request.httpMethod = "HEAD"
    request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringLocalAndRemoteCacheData
    request.timeoutInterval = 10.0
    
    var response: URLResponse?
    _ = try? NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response) as Data?
    
    if let httpResponse = response as? HTTPURLResponse {
        if httpResponse.statusCode == 200 {
            Status = true
        }
    }
    return Status
}

func RGBA(_ r:CGFloat, g:CGFloat, b:CGFloat, a:CGFloat) -> UIColor {
    return UIColor(red: r/255, green: g/255, blue: b/255, alpha: a)
}

let kUserBean = "UserBeanadfkswl"
let kDeviceToken = "DeviceToken"
let kIsLoggedIn = "IsLoggedIn"


class Pref {
    class func setObject(_ obj : NSObject? , forKey:String) {
        let userDefaults = UserDefaults.standard
        if obj == nil {
            userDefaults.set(nil, forKey: forKey)
            userDefaults.synchronize()
        }
        else {
            let data = NSKeyedArchiver.archivedData(withRootObject: obj!)
            userDefaults.set(data, forKey: forKey)
            userDefaults.synchronize()
            return
        }
        
    }
    
    class func setObject(_ obj : Any? , forKey:String) {
        let userDefaults = UserDefaults.standard
        
        if obj == nil {
            userDefaults.set(obj, forKey: forKey)
            userDefaults.synchronize()
            return
        }
        else if obj is NSURL {
            userDefaults.set(obj as? URL, forKey: forKey)
        }
        else {
            userDefaults.set(obj, forKey: forKey)
        }
        userDefaults.synchronize()
    }
    
    class func getObjectForKey(_ theKey:String) -> Any? {
        let userDefaults = UserDefaults.standard
        let resultObject = userDefaults.object(forKey: theKey)
        if resultObject != nil && resultObject is Data {
            return NSKeyedUnarchiver.unarchiveObject(with: resultObject as! Data) as Any?
        }
        return UserDefaults.standard.object(forKey: theKey) as Any?
    }
}

func TO_INT(_ obj : Any) -> Int {
    
    
    let tmpObject = obj
    
    if let answer = tmpObject as? Int {
        return answer
    }
    else if let answer = tmpObject as? NSNumber {
        return answer.intValue
    }
    else if let answer = tmpObject as? String {
        return (answer as NSString).integerValue
    }
    
    
    return 0
}

func TO_DOUBLE(_ obj : Any) -> Double {
    
    
    let tmpObject = obj
    
    if let answer = tmpObject as? Double {
        return answer
    }
    else if let answer = tmpObject as? NSNumber {
        return answer.doubleValue
    }
    else if let answer = tmpObject as? String {
        return (answer as NSString).doubleValue
    }
    
    return 0
}


func TO_STRING(_ obj : Any) -> String {
    if obj is String {
        return (obj as! String)
    }
    else if obj is NSString {
        return obj as! String
    }
    
    return ""
}
func TO_Float(_ obj : Any) -> Float {
    
    //    let tmpObject = (obj is String) ? obj as! String : obj
    let tmpObject = obj
    
    if let answer = tmpObject as? Float {
        return answer
    }
    else if let answer = tmpObject as? NSNumber {
        return answer.floatValue
    }
    else if let answer = tmpObject as? String {
        return (answer as NSString).floatValue
    }
    
    return 0
}

func RUN_AFTER_DELAY(_ delay: TimeInterval, block: @escaping ()->()) {
    let time = DispatchTime.now() + Double(Int64(delay * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
    DispatchQueue.main.asyncAfter(deadline: time, execute: block)
}

