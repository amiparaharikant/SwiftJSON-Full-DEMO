//  InAPPViewController.swift
//  Demo_SwiftJSON
//
//  Created by   on 12/04/17.
//  Copyright © 2017  . All rights reserved.

import UIKit
import StoreKit

class InAPPViewController: UIViewController
{
    var products = [SKProduct]()
    var aaa : NSMutableArray = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //CustomeMethod.hudShowDefault(self.view)
        
        let arrobj: CustomeMethod = CustomeMethod() //Create object of CustomeMethod
        aaa = arrobj.CommonDetail
        print("Result Array aaa \(aaa)")
        print("Result Array CommonDetail \(arrobj.CommonDetail)")
        print("Result Array UserDetail \(arrobj.UserDetail)")
        
        //MARK : TableView Refreshview
//        refreshControl = UIRefreshControl()
//        refreshControl?.addTarget(self, action: #selector(MasterViewController.reload), for: .valueChanged)
//        self.refreshControl?.endRefreshing()
        
        // Do any additional setup after loading the view.
        
        //CustomeMethod.showCustomeAlertTextfield(withTitle: "TextFieldDemo", withMessage: "Enter Detail", withButtonTitleLeft: "Cancel", withButtonTitleRight: "Done", withTextfieldTextHolderText: "Enter 123")
    }

    @IBAction func buttonInApp(_ sender: Any) {
        
        if UserDefaults.standard.bool(forKey: mRemoveAd) {
            CustomeMethod.showCustomeAlertOkCancel(withTitle:APP_Name, withMessage:"You Already Purchased Remove Ad", withButtonTitleLeft: "OK")
        }
        else {
            products = []
            RemoveAdProducts.store.requestProducts{success, products in
                if success {
                    self.products = products!
                    print("product array \(self.products)")
                    
                    let product = self.products[0]
                    RemoveAdProducts.store.buyProduct(product)
                }
            }
        }
    }
    
    @IBAction func buttonRestore(_ sender: Any) {
        
        RemoveAdProducts.store.restorePurchases()
//        if UserDefaults.standard.bool(forKey: mRemoveAd) {
//            
//            CustomeMethod.showCustomeAlertOkCancel(withTitle:APP_Name, withMessage:"You Already Restored...", withButtonTitleLeft: "OK")
//        }
//        else {
//            
//            let productIdentifiers: Set<ProductIdentifier> = [mRemoveAd]
//            let store = IAPHelper(productIds: productIdentifiers)
//            store.restorePurchases()
//        }
    }
    
//    override func hudShow()
//    {
//        MBProgressHUD.hide(for: self.view, animated: true)
//        
//        let HUD = MBProgressHUD.showAdded(to: self.view, animated: true);
//        
//        HUD?.labelText = "Loading"
//        HUD?.detailsLabelText = "Please Wait!!"
//        HUD?.isUserInteractionEnabled = true
//    }
//    
//    override func hudHide()
//    {
//        MBProgressHUD.hide(for: self.view, animated: true)
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
