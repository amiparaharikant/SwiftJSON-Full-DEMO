//
//  WebService.swift
//
//  PrePartureApp
//
//  Created by on 19/12/15.
//  Copyright © 2015 All rights reserved.
//

import UIKit
import Alamofire

//struct Alamofire {
//    static let manager = Manager.sharedInstance
//}
class WebService: NSObject {
    
    // Mark: Afnetworking
    
    class func postURL(_ serverlink:String,methodname:String,param:NSDictionary,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) //,userName:String,password:String
    {
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + "/" + methodname
        } else {
            fullLink = methodname
        }
        
        print("POST : " + serverlink + "/" + methodname + " and Param \(param)")
        
        Alamofire.request(fullLink, method: .post, parameters: param as? Parameters, encoding: URLEncoding.httpBody, headers: [:]).responseJSON { (response) in
            
            print(response)
            
            if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
            {
                if TempresponseDict.object(forKey: "status") != nil {
                    
                    if "\(TempresponseDict.object(forKey: "status")!)" == "1" {
                        CompletionHandler(true, TempresponseDict)
                    }else {
                        CompletionHandler(false, TempresponseDict)
                    }
                    
                    
                } else {
                    CompletionHandler(false, TempresponseDict)
                }
                
                
            } else {
                
                CompletionHandler(false, NSDictionary())
            }
        }
        
    }
    
    class func postImageToUrl(_ serverlink:String,methodname:String,param:NSDictionary,image:UIImage!,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
        
        print("POST : " + serverlink + methodname + " and Param \(param)")
        
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + "/" + methodname
        } else {
            fullLink = methodname
        }
        
        let imageData = UIImageJPEGRepresentation(image, 1.0)
        
        let notallowchar : CharacterSet = CharacterSet(charactersIn: "0123456789").inverted
        let dateStr:String = "\(Date())"
        let resultStr:String = (dateStr.components(separatedBy: notallowchar) as NSArray).componentsJoined(by: "")
        let imagefilename = "userImage_" + resultStr + ".jpg"
        
        
        Alamofire.upload(multipartFormData: { (formdata) in
            
            formdata.append(imageData!, withName: "img", fileName: imagefilename, mimeType: "image/jpeg")
            
            
            for (key, value) in param {
                
                formdata.append((value as! String).data(using: String.Encoding.utf8)!, withName: key as! String)
            }
            
            
        }, to: fullLink, encodingCompletion: { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.uploadProgress { progress in // main queue by default
                    print("Upload Progress: \(progress.fractionCompleted)")
                }
                
                upload.responseJSON { response in
                    print(response)
                    if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                    {
                        
                        if TempresponseDict.object(forKey: "response") != nil {
                            
                            if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                                CompletionHandler(true, TempresponseDict)
                            }else {
                                CompletionHandler(false, TempresponseDict)
                            }
                            
                            
                        } else {
                            CompletionHandler(false, TempresponseDict)
                        }

                        
                    } else {
                        
                        CompletionHandler(false, NSDictionary())
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                
                print("Fail to upload")
                CompletionHandler(false,NSDictionary())
            }
        })
        
        
    }
    
    class func statusPost(_ serverlink:String,methodname:String,param:NSDictionary,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
        
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + methodname
        } else {
            fullLink = methodname
        }
        
        //print("POST : " + fullLink + " and Param \(param)")
        print("POST : " + fullLink)
        
//        let myCustomRequest = NSMutableURLRequest(url: URL(string: fullLink)!)
//        
//        myCustomRequest.httpMethod = "POST"
//        myCustomRequest.httpBody = NSKeyedArchiver.archivedData(withRootObject: param)
        
   
        /*Alamofire.upload(multipartFormData: { (formdata) in
           
            for (key, value) in param {
                
                
                if let valueStr = value as? String {
                    formdata.append(valueStr.data(using: String.Encoding.utf8)!, withName: key as! String)
                } else if let vArr = value as? NSArray {
                    
                    do {
                     try formdata.append(JSONSerialization.data(withJSONObject: vArr, options: JSONSerialization.WritingOptions(rawValue: 0)), withName: key as! String)
                    } catch let error as NSError {
                        print(error.localizedDescription)
                    }
                }
                
            }
            
        }, to: fullLink, encodingCompletion: { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.uploadProgress { progress in // main queue by default
                    print("Upload Progress: \(progress.fractionCompleted)")
                    let dict = ["PercentDone":Float(progress.fractionCompleted)]
                    
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DisplayRemainTimeHud"), object: nil, userInfo: dict)
                }
                
                upload.responseJSON { response in
                    print(response)
                    if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                    {
                        
                        if TempresponseDict.object(forKey: "response") != nil {
                            
                            if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                                CompletionHandler(true, TempresponseDict)
                            }else {
                                CompletionHandler(false, TempresponseDict)
                            }
                            
                            
                        } else {
                            CompletionHandler(false, TempresponseDict)
                        }
                        
                        
                    } else {
                        
                        CompletionHandler(false, NSDictionary())
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                
                print("Fail to upload")
                CompletionHandler(false,NSDictionary())
            }
        })*/

        
        
        /*do {
            let bodyData = try PropertyListSerialization.data(fromPropertyList: param, format: PropertyListSerialization.PropertyListFormat.binary, options: PropertyListSerialization.WriteOptions.allZeros) //NSKeyedArchiver.archivedData(withRootObject: param)
            
            Alamofire.upload(bodyData, to: fullLink, method: .post, headers: [:]).uploadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                print("Progress: \(progress.fractionCompleted)")
                let dict = ["PercentDone":Float(progress.fractionCompleted)]
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "DisplayRemainTimeHud"), object: nil, userInfo: dict)
                }.responseJSON { (response) in
                    print(response)
                    
                    if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                    {
                        if TempresponseDict.object(forKey: "response") != nil {
                            
                            if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                                CompletionHandler(true, TempresponseDict)
                            }else {
                                CompletionHandler(false, TempresponseDict)
                            }
                            
                            
                        } else {
                            CompletionHandler(false, TempresponseDict)
                        }
                        
                        
                    } else {
                        
                        CompletionHandler(false, NSDictionary())
                    }
            }
        } catch let error as NSError {
            print(error.localizedDescription)
            CompletionHandler(false, NSDictionary())
        }*/
      
        
        Alamofire.request(fullLink, method: .post, parameters: param as? Parameters, encoding: URLEncoding.httpBody, headers: [:]).responseJSON { (response) in
                print(response)
                
                if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                {
                    if TempresponseDict.object(forKey: "response") != nil {
                        
                        if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                            CompletionHandler(true, TempresponseDict)
                        }else {
                            CompletionHandler(false, TempresponseDict)
                        }
                        
                        
                    } else {
                        CompletionHandler(false, TempresponseDict)
                    }
                    
                    
                } else {
                    
                    CompletionHandler(false, NSDictionary())
                }
        }
       
        
    }

    class func postImageArrayToUrl(_ serverlink:String,methodname:String,param:NSDictionary,imgArr:NSArray,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
        
        print("POST : " + serverlink + methodname + " and Param \(param)")
        
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + "/" + methodname
        } else {
            fullLink = methodname
        }
        
        Alamofire.upload(multipartFormData: { (formdata) in
            
            for (index,_) in imgArr.enumerated() {
                
                if let imageData : Data = imgArr.object(at: index) as? Data {
                    
                    
                    let notallowchar : CharacterSet = CharacterSet(charactersIn: "0123456789").inverted
                    let dateStr:String = "\(Date())"
                    let resultStr:String = (dateStr.components(separatedBy: notallowchar) as NSArray).componentsJoined(by: "")
                    let imagefilename = "userImage_" + resultStr + ".jpg"
                    
                    formdata.append(imageData, withName: "img\(index+1)", fileName: imagefilename, mimeType: "image/jpeg")
                }
                
            }
            
            
            for (key, value) in param {
                
                formdata.append((value as! String).data(using: String.Encoding.utf8)!, withName: key as! String)
            }
            
            
        }, to: fullLink, encodingCompletion: { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.uploadProgress { progress in // main queue by default
                    print("Upload Progress: \(progress.fractionCompleted)")
                }
                
                upload.responseJSON { response in
                    print(response)
                    if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                    {
                        
                        if TempresponseDict.object(forKey: "status") != nil {
                            
                            if "\(TempresponseDict.object(forKey: "status")!)" == "1" {
                                CompletionHandler(true, TempresponseDict)
                            }else {
                                CompletionHandler(false, TempresponseDict)
                            }
                            
                            
                        } else {
                            CompletionHandler(false, TempresponseDict)
                        }

                        
                    } else {
                        
                        CompletionHandler(false, NSDictionary())
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
                
                print("Fail to upload")
                CompletionHandler(false,NSDictionary())
            }
        })
        
        
    }
    
    
    class func postVideoToURL(_ serverlink:String,methodname:String,param:NSDictionary,videoUrl:URL,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ())
    {
        
        print("POST : " + serverlink + methodname + " and Param \(param)")
        
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + "/" + methodname
        } else {
            fullLink = methodname
        }
        
        do {
            
            let videoData = try Data(contentsOf: videoUrl)
            
            let notallowchar : CharacterSet = CharacterSet(charactersIn: "0123456789").inverted
            let dateStr:String = "\(Date())"
            let resultStr:String = (dateStr.components(separatedBy: notallowchar) as NSArray).componentsJoined(by: "")
            let imagefilename = "userImage_" + resultStr + ".mov"
            
            
            Alamofire.upload(multipartFormData: { (formdata) in
                
                formdata.append(videoData, withName: "img", fileName: imagefilename, mimeType: "video/quicktime")
                
                
                for (key, value) in param {
                    
                    formdata.append((value as! String).data(using: String.Encoding.utf8)!, withName: key as! String)
                }
                
                
            }, to: fullLink, encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress { progress in // main queue by default
                        print("Upload Progress: \(progress.fractionCompleted)")
                    }
                    
                    upload.responseJSON { response in
                        print(response)
                        if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
                        {
                            
                            if TempresponseDict.object(forKey: "response") != nil {
                                
                                if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                                    CompletionHandler(true, TempresponseDict)
                                }else {
                                    CompletionHandler(false, TempresponseDict)
                                }
                                
                                
                            } else {
                                CompletionHandler(false, TempresponseDict)
                            }
                            
                            
                        } else {
                            
                            CompletionHandler(false, NSDictionary())
                        }
                    }
                    
                case .failure(let encodingError):
                    print(encodingError)
                    
                    print("Fail to upload")
                    CompletionHandler(false,NSDictionary())
                }
            })

        } catch let e as NSError {
            print(e.localizedDescription)
        } catch {
            
        }
    }
    
    class func postToURLWithRemainingTime(_ serverlink:String,methodname:String,param:NSDictionary,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) //,userName:String,password:String
    {
        
        print("POST : " + serverlink + methodname + " and Param \(param)")
        
        var fullLink = serverlink
        
        if fullLink.characters.count > 0 {
            fullLink = serverlink + "/" + methodname
        } else {
            fullLink = methodname
        }
        
       // [userInfo setObject:[NSString stringWithFormat:@"%f",uploadProgress.fractionCompleted] forKey:@"PercentDone"];
        //[[NSNotificationCenter defaultCenter] postNotificationName:@"DisplayRemainTime" object:nil userInfo:userInfo];
        
        Alamofire.request(fullLink, method: .post, parameters: param as? Parameters, encoding: URLEncoding.httpBody, headers: [:]).responseJSON { (response) in
            
            print(response)
            
            if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
            {
                if TempresponseDict.object(forKey: "response") != nil {
                    
                    if "\(TempresponseDict.object(forKey: "response")!)" == "1" {
                        CompletionHandler(true, TempresponseDict)
                    }else {
                        CompletionHandler(false, TempresponseDict)
                    }
                    
                    
                } else {
                    CompletionHandler(false, TempresponseDict)
                }
                
                
            } else {
                
                CompletionHandler(false, NSDictionary())
            }
        }
        
    }
    
//    class func googleNearBySearchForLocation(_ lat: String, _ long: String, _ name: String, _ types: String,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
//
//        var googleLink = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=\(lat),\(long)&radius=5000&types=\(types)&sensor=false&key=\(KGoogleKey)"
//
//        if name.characters.count > 0 {
//            googleLink = googleLink + "&name=\(name)"
//        }
//
//        self.CallRequestUrl(googleLink) { (result, dict) in
//            CompletionHandler(result,dict)
//        }
//    }
    
    class func CallRequestUrl(_ serverlink:String,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
        
        print("Google Link : \(serverlink)")
        
        Alamofire.request(serverlink, method: .get, parameters: nil, encoding: URLEncoding.httpBody, headers: nil).responseJSON { (response) in
            
            print(response)
            if let TempresponseDict:NSDictionary = response.result.value as? NSDictionary
            {
                
                CompletionHandler(true, TempresponseDict)
                
            } else {
                
                CompletionHandler(false, NSDictionary())
            }
        }
        
    }
   
//    class func GetPlaceDetailByPlaceId(_ place_id:String,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
//
//        if place_id.characters.count > 0 {
//            let GdetailLink : String = "https://maps.googleapis.com/maps/api/place/details/json?placeid="  + place_id  + "&key=\(KGoogleKey)"
//
//            WebService.CallRequestUrl(GdetailLink) { (success, response) in
//                CompletionHandler(success, response)
//            }
//
//        } else {
//            let errDict:NSDictionary = ["message":"Place Id not found"]
//            CompletionHandler(false,errDict)
//        }
//
//    }
//
//    class func GetAutoCompletePlaces(_ inputText:String,locationString: String, radiusString: String, strTypes: String,CompletionHandler:@escaping (_ success:Bool,_ response:NSDictionary) -> ()) {
//
//        let encodedInput = inputText.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlHostAllowed)!
//
//        let typesString = strTypes.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlHostAllowed)!
//
//        //https://maps.googleapis.com/maps/api/place/autocomplete/json?input=Indu&sensor=true&key=AIzaSyBVdxJI0jbuBw9nx9FRgjW57dshijFieyo&location=23.0280562,72.557758&radius=2000.000000
//
//        let fullLink = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=\(encodedInput)&sensor=false&key=\(KGoogleKey)&location=\(locationString)&radius=\(radiusString)&types=\(typesString)"
//
//        WebService.CallRequestUrl(fullLink) { (success, response) in
//            CompletionHandler(success, response)
//        }
//
//    }
//
//    //MARK: - My reusable methods
//
//
}

