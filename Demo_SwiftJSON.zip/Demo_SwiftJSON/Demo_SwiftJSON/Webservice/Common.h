//
//  Common.h
//  Demo
//
//  Created by Demo on 21/11/17.
//  Copyright © 2017 Demo. All rights reserved.
//

#ifndef Common_h
#define Common_h

#define MAIN_LINK @"MainURL" //past your main url

#define DEVICE_TYPE @"2"
#define FIRST_KEY @"chd"
#define DEIVACE_ID @"252926adsarq145qwe46qw46e4qw"

#define REGISTER @"registration"

#define LOGIN @"login" //first_key,email,device_id,device_type(1-Android, 2-IOS),password,token

#define FORGOTE_PASS @"forgotPassword" //first_key,email

#define COMMON_DETAIL @"commonDetails" //first_key

#define DENTAL_PROBLEM @"dentalProblemPost" //api_key,user_id,message,img1(base 64 image string),img2(base 64 image string)

#define SECOND_OPINION @"secondOpinionPost" //api_key,user_id,message,img1(base 64 image string),img2(base 64 image string)

#define TAKE_APPOINMENT @"takeAppoinment" // api_key,user_id,name,email,telephone,subject,message

#define CHANGE_PASSWORD @"passwordChange" //api_key,user_id,old_password,new_password



#endif /* Common_h */
