//  AdCustomeViewController.swift
//  Demo_SwiftJSON
//
//  Created by   on 06/04/17.
//  Copyright © 2017  . All rights reserved.

import UIKit
import GoogleMobileAds
import Foundation

class AdCustomeViewController: UIViewController,GADInterstitialDelegate,GADBannerViewDelegate {

    @IBOutlet weak var adsView: UIView!
    //@IBOutlet weak var bannerView: GADBannerView!
    var isAdReady = false
    // the interstitial
    var interstitial: GADInterstitial?
    var bannerView: GADBannerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        bannerView = CustomeMethod.addGADBannerView_ViewController(self)
        //bannerView = CustomeMethod.addGADBannerView_ViewController(self)
        bannerView?.delegate = self
        bannerView?.rootViewController = self
        self.view.addSubview(bannerView)
        bannerView.isHidden = true
        
        interstitial = CustomeMethod.addGADInterstitial_ViewController(self)
        
        perform(#selector(AdCustomeViewController.FullScreenAdShow), with:nil, afterDelay:4.0)
      
        // Do any additional setup after loading the view.
    }

    func adViewDidReceiveAd(_ bannerView: GADBannerView)
    {
        if CustomeMethod.isAdisReadyToviewBanner() {
           bannerView.isHidden = false
            print("Bannerview Add:")
        }else{print("Bannerview Block for today:")}
    }
    
    func adView(_ bannerView: GADBannerView,
                didFailToReceiveAdWithError error: GADRequestError) {
        print("adView:didFailToReceiveAdWithError: \(error.localizedDescription)")
    }
    
    func FullScreenAdShow()
    {
        isAdReady = false
        interstitial?.delegate = self
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(mINTERSTETIALADTIMEAFTER * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: {() -> Void in
            self.isAdReady = true
            let currentViewController: UIViewController? = self.navigationController?.visibleViewController
            
            if currentViewController == self {
                if self.isAdReady && CustomeMethod.isAdisReadyToviewIntrestial() {
                    self.interstitial?.present(fromRootViewController: self)
                }
            }
        })
    }
    
    // MARK: - Click-Time Lifecycle Notifications -
    func interstitialWillPresentScreen(_ ad: GADInterstitial) {
//        let startTime = UserDefaults.standard.double(forKey: klastIntAdShowTime)
//        let now = Date().timeIntervalSince1970
//        let elapsed = now - startTime
//        
//        if elapsed > mShowAdAfter
//        {
//        }
        
        CustomeMethod.showingInterstitialAdonController(self)
    }
    
    func interstitialWillDismissScreen(_ ad: GADInterstitial) {
        CustomeMethod.dismissInterstitialAdonController(self)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double((mShowAdAfter + 5) * Double(NSEC_PER_SEC)) / Double(NSEC_PER_SEC), execute: {() -> Void in
            
            let currentViewController: UIViewController? = self.navigationController?.visibleViewController
            
            if currentViewController == self
            {
                self.FullScreenAdShow()
            }
        })
    }
    
    func interstitialWillLeaveApplication(_ ad: GADInterstitial) {
        CustomeMethod.clickOnAdHappenonController(self)
    }
    
    func interstitialDidReceiveAd(_ ad: GADInterstitial)
    {
        if isAdReady
        {
            ad.present(fromRootViewController: self)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
