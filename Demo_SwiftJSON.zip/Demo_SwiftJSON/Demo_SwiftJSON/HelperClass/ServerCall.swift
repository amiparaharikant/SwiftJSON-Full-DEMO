//
//  ServerCall.swift
//  ClassPass
//
//  Created by on 20/02/17.
//  Copyright © 2017 MAC-2. All rights reserved.
//

import Foundation
import Alamofire

let DEVICE_TYPE = "2"
let FIST_KEY = "chd"
let DEIVACE_ID = "252926adsarq145qwe46qw46e4qw"
let _userDefault : UserDefaults = UserDefaults.standard

//url
private var URL_BASE = "URL"

let URL_REGISTER = URL_BASE + "/registration"
//let URL_LOGIN = URL_BASE + "/api/user/login"


enum HTTP_METHOD {
    case http_GET, http_POST
}

enum ServerCallName : Int {
    case Register_Url = 101,
    LogIn
}

protocol ServerCallDelegate {
    func ServerCallSuccess(_ resposeObject: AnyObject, name: ServerCallName)
    func ServerCallFailed(_ errorObject:String, name: ServerCallName)
}

extension UIImage {
    // Loads image asynchronously
    class func loadFromPath(_ path: String, callback:@escaping (UIImage) -> Void ) {
        Alamofire.request(path).responseData { (theResponse : DataResponse<Data>) in
            if let imgData = theResponse.data {
                if let img = UIImage(data: imgData) {
                    callback(img)
                }
                else {
                    callback(UIImage())
                }
            }
            else {
                callback(UIImage())
            }
        }
    }
}

class ServerCall: NSObject {
    var delegateObject : ServerCallDelegate!
    
    // Shared Object Creation
    static let sharedInstance = ServerCall()
    
    // Make API Request WITHOUT Header Parameters
    
    func requestWithURL(_ httpMethod: HTTP_METHOD, urlString: String, delegate: ServerCallDelegate, name: ServerCallName) {
        self.delegateObject = delegate
        let methodOfRequest : HTTPMethod = (httpMethod == HTTP_METHOD.http_GET) ? HTTPMethod.get : HTTPMethod.post
        let queue = DispatchQueue(label: "com.demo.manager-response-queue", attributes: DispatchQueue.Attributes.concurrent)
        let request = Alamofire.request(urlString, method: methodOfRequest, parameters: nil)
        request.responseJSON(queue: queue,options: JSONSerialization.ReadingOptions.allowFragments)
        {
            (response : DataResponse<Any>) in
            // You are now running on the concurrent `queue` you created earlier.
            print("Parsing JSON on thread: \(Thread.current) is main thread: \(Thread.isMainThread)")
            print(response.result.value!)
            // To update anything on the main thread, just jump back on like so.
            DispatchQueue.main.async {
                print("Am I back on the main thread: \(Thread.isMainThread)")
                if (response.result.isSuccess) {
                    self.delegateObject.ServerCallSuccess(response.result.value! as AnyObject, name: name)
                }
                else if (response.result.isFailure) {
                    self.delegateObject.ServerCallFailed((response.result.error?.localizedDescription)!, name: name)
                }
            }
        }
        
    }
    
    // Make API Request WITH Parameters
    func requestWithUrlAndParameters(_ httpMethod: HTTP_METHOD, urlString: String, parameters: [String : AnyObject], delegate: ServerCallDelegate, name: ServerCallName) {
        
        self.delegateObject = delegate
        let methodOfRequest : HTTPMethod = HTTPMethod.post
        
        let queue = DispatchQueue(label: "com.demo.manager-response-queue", attributes: DispatchQueue.Attributes.concurrent)
        
        _ = URL(string: urlString)
        
        let request = Alamofire.request(urlString, method: methodOfRequest, parameters: parameters)
        request.responseJSON(queue: queue,
                             options: JSONSerialization.ReadingOptions.allowFragments) {
                                (response : DataResponse<Any>) in
                                
                                
//                                print("\n\n request ---------> ")
//                                print(response.request!)
//                                print("\n\n")
//                                print(parameters)
//                                print("\n\n Response ---------> ")
//                                print(response)
//                                print("\n\n")
//                                print(response.data!)
//                                print("\n\n")
//                                print(response.result.description)
//                                print("\n\n")
//                                print(response.data! as NSData)
                                
                                DispatchQueue.main.async {
                                    print("Am I back on the main thread: \(Thread.isMainThread)")
                                    if (response.result.isSuccess) {
                                        self.delegateObject.ServerCallSuccess(response.result.value! as AnyObject, name: name)
                                    }
                                    else if (response.result.isFailure) {
                                        self.delegateObject.ServerCallFailed((response.result.error?.localizedDescription)!, name: name)
                                    }
                                }
        }
    }
    
    // Make API Request WITH Header
    func requestWithUrlAndHeader(_ httpMethod: HTTP_METHOD, urlString: String, header: [String : String], delegate: ServerCallDelegate, name: ServerCallName) {
        self.delegateObject = delegate
        let methodOfRequest : HTTPMethod = (httpMethod == HTTP_METHOD.http_GET) ? HTTPMethod.get : HTTPMethod.post
        
        let queue = DispatchQueue(label: "com.demo.manager-response-queue", attributes: DispatchQueue.Attributes.concurrent)
        
        let request = Alamofire.request(urlString, method: methodOfRequest, parameters: nil, encoding: JSONEncoding.default, headers: header)
        
        request.responseJSON(queue: queue,options: JSONSerialization.ReadingOptions.allowFragments)
        {
            (response : DataResponse<Any>)
            in DispatchQueue.main.async
                {
                    print("Am I back on the main thread: \(Thread.isMainThread)")
                    if (response.result.isSuccess) {
                        self.delegateObject.ServerCallSuccess(response.result.value! as AnyObject, name: name)
                    }
                    else if (response.result.isFailure) {
                        self.delegateObject.ServerCallFailed((response.result.error?.localizedDescription)!, name: name)
                    }
            }
        }
    }
    //MARK:- Multi part request with parameters.
    func requestMultiPartWithUrlAndParameters(_ urlString: String, parameters: [String : AnyObject], image: UIImage, imageParameterName: String, imageFileName:String, delegate: ServerCallDelegate, name: ServerCallName) {
        
        self.delegateObject = delegate
        var imageData : Data!
        imageData = UIImagePNGRepresentation(image)
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                // The for loop is to append all parameters to multipart form data.
                for element in parameters.keys{
                    let strElement = String(element)
                    let strValueElement = parameters[strElement!] as! String
                    multipartFormData.append(strValueElement.data(using: String.Encoding.utf8, allowLossyConversion: false)!, withName: strElement!)
                }
                
                // Append Image to multipart form data.
                multipartFormData.append(imageData, withName: imageParameterName, fileName: imageFileName + ".png", mimeType: "image/png")
        },
            to: urlString,
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        debugPrint(response)
                        //                        print(response.result.value!)
                        //                        print(response.data as! NSData)
                        self.delegateObject.ServerCallSuccess(response.result.value! as AnyObject, name: name)
                    }
                case .failure(let encodingError):
                    print(encodingError)
                    self.delegateObject.ServerCallFailed(encodingError.localizedDescription, name: name)
                }
        }
        )
    }

}
