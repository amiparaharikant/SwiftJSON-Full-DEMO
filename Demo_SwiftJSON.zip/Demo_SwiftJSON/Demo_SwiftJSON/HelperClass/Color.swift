//
//  Color.swift


import Foundation
import UIKit


let COLOR_COMMON_DARK_BLUE = UIColor(hexString: "#4C6E8D")
let COLOR_COMMON_LIGHT_ORNAGE = UIColor(hexString: "#fe903e")

let COLOR_COMMON_DARK_BLACK = UIColor(hexString: "#272828")
let COLOR_COMMON_LIGHT_BLACK = UIColor(hexString: "#595959")

let COLOR_TEXTFIELD_B = UIColor(red: 76/255, green: 110/255, blue: 141/255, alpha: 1)
 
let COLOR_BUTTON_SELECTED_BG = COLOR_COMMON_LIGHT_ORNAGE
let COLOR_BUTTON_UNSELECTED_BG = UIColor(red: 246/255, green: 246/255, blue: 246/255, alpha: 1)

let COLOR_BUTTON_SELECTED_Text = UIColor.white
let COLOR_BUTTON_UNSELECTED_Text = COLOR_COMMON_LIGHT_BLACK

extension UIColor {
    convenience init(hexString: String) {
        var cString:String =  hexString.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString = cString.substring(from: cString.characters.index(cString.startIndex, offsetBy: 1))
        }
        
        var red : CGFloat = 0.0
        var green : CGFloat = 0.0
        var blue : CGFloat = 0.0
        
        if ((cString.characters.count) != 6) {
            red = 0
            green = 0
            blue = 0
        } else {
            var rgbValue:UInt32 = 0
            Scanner(string: cString).scanHexInt32(&rgbValue)
            red = CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0
            green = CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0
            blue = CGFloat(rgbValue & 0x0000FF) / 255.0
        }
        self.init(red: red, green: green, blue: blue, alpha: 1.0)
    }
}


extension CALayer {
    
    func addBorder(_ edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let border = CALayer();
        
        switch edge {
        case UIRectEdge.top:
            border.frame = CGRect(x: 0, y: 0, width: self.frame.width, height: thickness);
            break
        case UIRectEdge.bottom:
            border.frame = CGRect(x: 0, y: self.frame.height - thickness, width: self.frame.width, height: thickness)
            break
        case UIRectEdge.left:
            border.frame = CGRect(x: 0, y: 0, width: thickness, height: self.frame.height)
            break
        case UIRectEdge.right:
            border.frame = CGRect(x: self.frame.width - thickness, y: 0, width: thickness, height: self.frame.height)
            break
//        case UIRectEdge.All:
//            border.frame = self.bounds
//            break
        default:
            break
        }
        
        border.backgroundColor = color.cgColor;
        
        self.addSublayer(border)
    }
}
